#ifndef STB_MAIN_H_INCLUDED
#define STB_MAIN_H_INCLUDED

#include "stb_image.h"
#include "stb_image_write.h"
//#include "stb_image_resize.h"

#endif /* STB_MAIN_H_INCLUDED */
