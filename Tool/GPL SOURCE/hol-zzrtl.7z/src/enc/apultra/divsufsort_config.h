#define HAVE_STRING_H 1
#define HAVE_STDLIB_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STDINT_H 1
#define INLINE inline

#ifdef _MSC_VER
#pragma warning( disable : 4244 )
#endif /* _MSC_VER */
