echo "-DNDEBUG -Wall -flto -lm -Os -s -flto -Iwowlib -DWOW_OVERLOAD_FILE src/*.c -Isrc "
