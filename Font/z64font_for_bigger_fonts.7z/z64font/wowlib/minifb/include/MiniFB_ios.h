#pragma once

#include <MiniFB_enums.h>

void user_implemented_init(struct mfb_window *window);

void user_implemented_update(struct mfb_window *window);
