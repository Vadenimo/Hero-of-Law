pkg-config --cflags --libs gtk+-2.0
echo "-no-pie -lX11 -lm -lpthread"
