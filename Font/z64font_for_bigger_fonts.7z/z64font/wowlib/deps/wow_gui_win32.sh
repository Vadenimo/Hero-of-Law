echo "-mwindows -lgdi32 -luser32 -lkernel32 -lm"
