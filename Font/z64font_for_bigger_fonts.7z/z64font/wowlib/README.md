# wowlib

`wowlib` is a growing collection of functions that make writing software in C easier. It currently offers file loading helpers, an abstraction layer that makes supporting Unicode more seamless, and a self-explanatory immediate-mode GUI library.



